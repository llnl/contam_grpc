This repo contains an example Java driver and associated JNA 
bindings (*cxLibInterface.java*) for *contamx-lib* (.so/.dll). 
These were developed and tested using *IntelliJ IDEA* on *Windows 10*.  

The driver utilizes the latest version (3.4.1.10) of the DLL 
(shared object) located in the */resources* folder.  

The */contamx-artifacts* folder contains *Windows* and *Linux* 
versions of both *contamx-lib* and *contamp-lib* along with associated 
header files and example drivers written in the C programming language. 

Documentation can be generated from the compressed files located in 
the */contamx-artifacts* folder. See the *readme-examples.md* file 
located in the artifacts for instructions on how to generate HTML 
documentation using *doxygen*.
