package gov.nist.runcontamxdll;
import com.sun.jna.Native;
import com.sun.jna.Pointer;
import com.sun.jna.ptr.DoubleByReference;

import com.sun.jna.ptr.IntByReference;
import cxLibs.cxLibInterface;
import cxLibs.cxLibConsts;
import cxLibs.WthCtmData;

import java.io.File;
import java.util.ArrayList;
import java.util.Formatter;
import java.util.List;

//-------------------------------------------------------------------------------------------------
// Using Java Native Access (JNA) to run contamx-lib.dll
//
// This driver is for use with CONTAM project testOneZoneWthCtm-UseApi.prj
// The project file contains 1 contaminant: sarin implemented as an outdoor source.
//-------------------------------------------------------------------------------------------------
@SuppressWarnings("SpellCheckingInspection")
public class RunContamxDll {
    static cxLibInterface cxLib;

    // List of envelope path ids.
    public static List<Integer> envPathList = new ArrayList<>();
    public static List<Integer> envIndexList = new ArrayList<>();

    // User-defined callback error function.
    public static cxLibInterface.CallBackErrorFnName fnError = new cxLibInterface.CallBackErrorFnName() {
        @Override
        public void callback(Pointer contamXState, Pointer pHeader, Pointer pMessage, IntByReference pNonFatalErrorCount) {
            byte[] headArr = pHeader.getByteArray(0, 64);
            byte[] messageArr = pMessage.getByteArray(0, 256);
            System.out.println("contamx-lib errCount = " + pNonFatalErrorCount.getValue());
            System.out.println("  " + Native.toString(headArr) + ": " + Native.toString(messageArr));

            String headStr = Native.toString(headArr);
            if (headStr.equals("FATAL"))
            {
                System.out.println("FATAL error encountered in contamx-lib will cause this program to exit.");
            }
        }
    };

    // User-defined prjDataReady callback function.
    public static cxLibInterface.CallBackFnName fnPrjDataReady = new cxLibInterface.CallBackFnName() {
        @Override
        public void callback(Pointer cxs, Pointer pUD) {
            byte[] strVersion = new byte[64];

            System.out.println("called prjDataReadyFcnP_t");
            cxLib.cxiGetVersion(cxs, strVersion);
            System.out.println("contamx-lib version = " + Native.toString(strVersion));

            int simStage = getStage(cxs);
            System.out.println("==========> 2. simStage = " + simStage);

            int numContaminants = cxLib.cxiGetNumCtms(cxs);
            int numPaths = cxLib.cxiGetNumPaths(cxs);
            System.out.printf("Number of contaminants = %d\n", numContaminants);
            System.out.printf("Number of airflow paths = %d\n", numPaths);
            int envCount = 0;
            cxLibInterface.PATH_COSIM_DSC pd = new cxLibInterface.PATH_COSIM_DSC();
            for(int iPath = 1; iPath <= numPaths; iPath++){
                if (cxLib.cxiGetPathInfo(cxs, iPath, pd) > 0){
                    return;
                }
                // envIndex > 1 designates an envelope path.
                if ( pd.envIndex > 0) {
                    envIndexList.add(pd.envIndex);
                    envPathList.add(pd.nr);
                    envCount++;
                }
                System.out.printf("Path %d, envIndex = %d, envCount = %d\n", iPath, pd.envIndex, envCount);
            }

            // Set initial ambient properties to be used during steady state initialization.
            cxLib.cxiSetAmbtTemperature(cxs, WthCtmData.Tambt[0]);
            cxLib.cxiSetAmbtPressure(cxs, WthCtmData.Pambt[0]);
            cxLib.cxiSetAmbtWndSpd(cxs, WthCtmData.WSambt[0]);
            cxLib.cxiSetAmbtWndDir(cxs, WthCtmData.WDambt[0]);
            cxLib.cxiSetAmbtMassFraction(cxs, 0, WthCtmData.Mf[0]);
        }
    };

    public static void getZoneMf(Pointer cxs, Formatter fmt, int date, int time, int nz, int nc)
    {
        DoubleByReference pMf = new DoubleByReference();
        byte[] bufName = new byte[cxLibConsts.NAMEFIELDLEN];
        for (int iZone = 1; iZone <= nz; ++iZone)
        {
            for (int iCtm = 0; iCtm < nc; ++iCtm)
            {
                if (cxLib.cxiGetZoneMF(cxs, iZone, iCtm, pMf) > 0 ){
                    return;
                }
                if(cxLib.cxiGetCtmName(cxs, iCtm, bufName) > 0 ) {
                    return;
                }
                fmt.format("Day %d Time %d Zone %d %s %g kg/kg\n",
                        date, time, iZone, Native.toString(bufName), pMf.getValue());
                fmt.flush();
            }
        }
    }

    public static void getEnvExfil(Pointer cxs, Formatter fmt, int date, int time, int nc)
    {
        byte[] bufName = new byte[cxLibConsts.NAMEFIELDLEN];
        DoubleByReference pMass = new DoubleByReference();
        for (Integer iIdx:envIndexList) {
            fmt.format("Day %d Time %d envIndex %d Path %d ", date, time, iIdx, envPathList.get(iIdx - 1));
            for (int iCtm = 0; iCtm < nc; ++iCtm) {
                if (cxLib.cxiGetEnvelopeExfil(cxs, iIdx, iCtm, pMass) > 0) {
                    return;
                }
                if (cxLib.cxiGetCtmName(cxs, iCtm, bufName) > 0) {
                    return;
                }
                fmt.format(" %s %g kg", Native.toString(bufName), pMass.getValue());
            }
            fmt.format("\n");
            fmt.flush();
        }
    }

    public static int getStage(Pointer cxs)
    {
        int stage = cxLib.cxiGetSimStage(cxs);
        String[] stageNames={"simStage_Invalid","simStage_Initial","simStage_Setup","simStage_Calculation","simStage_End"};
        System.out.println("\nCurrent simulation stage is " + stageNames[stage]);
        return  stage;
    }

    //-------------------------------------------------------------------------------------------------
    //----- main
    //-------------------------------------------------------------------------------------------------
    //   NOTES:
    // - PRJ filename and contam-lib DLL/SO are hard-coded within this routine.
    // - This driver is specific to the PRJ referenced herein.
    //-------------------------------------------------------------------------------------------------
    public static void main(String[] args) throws Exception{

        // General variables
        int ans;
        int simStage;
        Pointer cxState;

        //-----  Set input PRJ file name w/o extension.
        String prjName = "demoOneZoneWthCtm-UseApi";
//        String prjName = "demoOneZoneWthCtm-UseApi-noOutput";
//        String prjName = "demoOneZoneWthCtm-UseApi-timestep60sec-runtime4hours";

        // Manage input and output files.
        String prjFileName = prjName + ".prj";
        String zoneMfFileName = prjName + "-zoneMf.txt";
        String envExfilFileName = prjName + "-envEx.txt";

        File zmfFile = new File(zoneMfFileName);
        //noinspection ResultOfMethodCallIgnored
        zmfFile.createNewFile();
        Formatter zmfFormatter = new Formatter(zmfFile);
        File exfilFile = new File(envExfilFileName);
        exfilFile.createNewFile();
        Formatter exfilFormatter = new Formatter(exfilFile);

        System.out.println("Running ContamX with co-simulation!!!");

        //-----  Initialize the interface to the contamx DLL.
        // NOTE: Shared lib name is hard-coded here.
        // Care must be taken to ensure DLL is in a "reachable" location.
        // Here using setProperty to '..\resources' directory where DLL is located.
        System.setProperty("jna.library.path", "..\\resources");
        cxLib = Native.load("contamx-lib", cxLibInterface.class);

        //----- Get the ContamXState.
        cxState = cxLib.cxiGetContamState();

        simStage = getStage(cxState);
        System.out.println("==========> 1. simStage = " + simStage);

        //-----  Set pointer to callback function defined above.
        cxLib.cxiRegisterCallback_PrjDataReady(cxState, Pointer.NULL, fnPrjDataReady);
        cxLib.cxiRegisterCallback_Error(cxState, fnError);
        cxLib.cxiSetCosimOption(cxState, cxLibInterface.eCosimOption.cosimOpt_densityCalc, cxLibInterface.eDensityCalc.densityCalc_ContamX );

        //-----  Set wind pressure mode to WTH/CTM method.
        // Must be called before cxiSetupSimulation().
        cxLib.cxiSetWindPressureMode(cxState, 0);

        //--------------------------------------------------------------
        //-----  Read the PRJ file AND run steady state initialization.
        //--------------------------------------------------------------
        ans = cxLib.cxiSetupSimulation(cxState, prjFileName, 1);

        simStage = getStage(cxState);
        System.out.println("==========> 3. simStage = " + simStage);

        int numContams = cxLib.cxiGetNumCtms(cxState);
        int numZones = cxLib.cxiGetNumZones(cxState);

        // Get simulation timing information.
        int simTimeStep = cxLib.cxiGetSimulationTimeStep(cxState);
        int simStartDate = cxLib.cxiGetSimulationStartDate(cxState);
        int simStartTime = cxLib.cxiGetSimulationStartTime(cxState);
        int simEndDate = cxLib.cxiGetSimulationEndDate(cxState);
        int simEndTime = cxLib.cxiGetSimulationEndTime(cxState);
        int simBegin = (simStartDate - 1) * 86400 + simStartTime;
        int simEnd = (simEndDate - 1) * 86400 + simEndTime;
        // Calculate the simlation duration in seconds.
        int simDuration;
        if (simBegin < simEnd)
            simDuration = simEnd - simBegin;
        else
            simDuration = 365 * 86400 - simEnd + simBegin;

        // Calculate the number of steps to reach the end of the simulation.
        int numTimeSteps = simDuration / simTimeStep;

        // Get the current date/time after initial steady state simulation.
        int currentDate, currentTime;
        currentTime = cxLib.cxiGetCurrentTime(cxState);
        currentDate = cxLib.cxiGetCurrentDate(cxState);

        // Get initial zone mass fractions and write to zmfFile.
        getZoneMf(cxState, zmfFormatter, currentDate, currentTime, numZones, numContams);
        // Get initial envelope exfiltration and write to exfilFile.
        getEnvExfil(cxState, exfilFormatter, currentDate, currentTime, numContams);

        // Set index into WthCtmData.
        int WthCtm_index = 0;
        WthCtm_index++;
        //----- Loop through the simulation one time step at a time.
        for (int i = 0; i < numTimeSteps; i++)
        {
            //----- Tasks to perform before current time step.

            // Set envelope infiltration data according to WthCtmData class.
            if (currentTime /*+ simTimeStep*/ == WthCtmData.times[WthCtm_index]) {
                System.out.println("WthCtm_index = " + WthCtm_index);
                cxLib.cxiSetAmbtTemperature(cxState, WthCtmData.Tambt[WthCtm_index]);
                cxLib.cxiSetAmbtPressure(cxState, WthCtmData.Pambt[WthCtm_index]);
                cxLib.cxiSetAmbtWndSpd(cxState, WthCtmData.WSambt[WthCtm_index]);
                cxLib.cxiSetAmbtWndDir(cxState, WthCtmData.WDambt[WthCtm_index]);
                cxLib.cxiSetAmbtMassFraction(cxState, 0, WthCtmData.Mf[WthCtm_index]);
                WthCtm_index++;
            }

            //----- Run current time step.
            cxLib.cxiDoCoSimStep(cxState, 1);

            //----- Tasks to perform after current time step.
            // Get new date/time.
            currentTime = cxLib.cxiGetCurrentTime(cxState);
            currentDate = cxLib.cxiGetCurrentDate(cxState);

            // Get zone mass fractions and write to zmfFile.
            getZoneMf(cxState, zmfFormatter, currentDate, currentTime, numZones, numContams);
            // Get envelope exfiltration and write to exfilFile.
            getEnvExfil(cxState, exfilFormatter, currentDate, currentTime, numContams);
        }

        simStage = getStage(cxState);
        System.out.println("==========> 4. simStage = " + simStage);

        cxLib.cxiEndSimulation(cxState);

        int stateValidity = cxLib.cxiIsStateValid(cxState);
        simStage = getStage(cxState);
        System.out.println("==========> 5. simStage = " + simStage + ", stateValidity = " + stateValidity);
    }
}
