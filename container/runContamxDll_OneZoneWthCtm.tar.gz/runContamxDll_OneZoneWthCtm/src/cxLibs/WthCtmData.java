package cxLibs;

// WTH and CTM data for testcase testOneZoneWthCtm-UseApi.prj.
//   This PRJ has one contaminant.
public final class WthCtmData {
 /*   // Use with testOneZoneWthCtm-UseApi-timestep60sec-runtime4hours.prj
    // time in seconds.
    //                                        0:00:00,   1:00:00,   1:01:00, 1:30:00,     22:55,   23:00,   24:00
    public final static int times[]    =   {        0,      3600,      3660,   54000,     82500,   8280,   86400};
    // T[]  temperature, K.
    public final static float Tambt[]  =   {  293.15f,   293.15f,   293.15f, 293.15f,   293.15f, 293.15f, 293.15f};
    // P[]  barometric pressure, Pa.
    public final static float Pambt[]  =   {  101325f,   101325f,   101325f, 101325f,   101325f, 101325f, 101325f};
    // WS[] wind speed, m/s.
    public final static float WSambt[] =   {   7.397f,    7.397f,     14.0f,   14.0f,     14.0f,    0.0f,    0.0f};
    // WD[] wind direction, degree.
    public final static float WDambt[] =   {   270.0f,    270.0f,     90.0f,   90.0f,     90.0f,    0.0f,    0.0f};
    // Mf[] mass fraction, kgc/kga.
    public final static double Mf[]    =   {0.0023254,       0.0,       0.0,0.0011627,0.0011627,     0.0,    0.0 };

    // Use with testOneZoneWthCtm-UseApi.prj
    // time in seconds.
    //                                          00:00,     06:00,     15:55,   16:00,     22:55,   23:00,   24:00
    public final static int times[]    =   {        0,     21600,     57300,   57600,     82500,   8280,   86400};
    // T[]  temperature, K.
    public final static float Tambt[]  =   {  293.15f,   293.15f,   293.15f, 293.15f,   293.15f, 293.15f, 293.15f};
    // P[]  barometric pressure, Pa.
    public final static float Pambt[]  =   {  101325f,   101325f,   101325f, 101325f,   101325f, 101325f, 101325f};
    // WS[] wind speed, m/s.
    public final static float WSambt[] =   {   7.397f,    7.397f,     14.0f,   14.0f,     14.0f,    0.0f,    0.0f};
    // WD[] wind direction, degree.
    public final static float WDambt[] =   {   270.0f,    270.0f,     90.0f,   90.0f,     90.0f,    0.0f,    0.0f};
    // Mf[] mass fraction, kgc/kga.
    public final static double Mf[]    =   {0.0023254,       0.0,       0.0,0.0011627,0.0011627,     0.0,    0.0 };
*/

    // time in seconds.
    //                                        00:00,     05:00,     05:05,     06:05,     06:10,     14:00,   14:05,     16:00,   16:05,     23:00,   23:05,   24:00
    public final static int[] times =   {      0,     18000,     18300,     21900,     22200,     50400,   50700,     57600,   57900,     82800,   83100,   86400};
    // T[]  temperature, K.
    public final static float[] Tambt =   {293.15f,   293.15f,   293.15f,   293.15f,   293.15f,   293.15f, 293.15f,   293.15f, 293.15f,   293.15f, 293.15f, 293.15f};
    // P[]  barometric pressure, Pa.
    public final static float[] Pambt =   {101325f,   101325f,   101325f,   101325f,   101325f,   101325f, 101325f,   101325f, 101325f,   101325f, 101325f, 101325f};
    // WS[] wind speed, m/s.
    public final static float[] WSambt =   {   0.0f,      0.0f,      0.0f,    7.397f,    7.397f,    7.397f,    0.0f,      0.0f,  7.397f,    7.397f,    0.0f,    0.0f};
    // WD[] wind direction, degree.
    public final static float[] WDambt =   {   0.0f,      0.0f,      0.0f,    270.0f,    270.0f,    270.0f,    0.0f,      0.0f,   90.0f,     90.0f,    0.0f,    0.0f};
    // Mf[] mass fraction, kgc/kga.
    public final static double[] Mf =   {    0.0,       0.0, 0.0023254, 0.0023254, 0.0023254, 0.0023254,     0.0,       0.0,    0.00,       0.0,     0.0,    0.0 };

}
