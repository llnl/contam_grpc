package cxLibs;
import com.sun.jna.Callback;
import com.sun.jna.Library;
import com.sun.jna.Pointer;
import com.sun.jna.Structure;
import com.sun.jna.ptr.DoubleByReference;
import com.sun.jna.ptr.FloatByReference;
import com.sun.jna.ptr.IntByReference;
import java.nio.channels.Pipe;

/* types.h data type mappings 64-bit
   Native (C)    Java
   --------------------------
   I1*, char* => byte[]
   U2         => short
   I4, IX     => int (4 byte)
   R4         => float
   R8         => double
*/
// These interfaces must match those provided in contamx-x-cosim.h
public interface cxLibInterface extends Library {

    public static interface eCosimOption
    {
        public static final int cosimOpt_flowType = 0;      /* Set airflow update units. */
        public static final int cosimOpt_densityCalc = 1;   /* Set density calculation method. */
        public static final int cosimOpt_Last = 2;          /* Placeholder after last option for range checking. */
    }

    public static interface eFlowType
    {
        public static final int flowType_MassFlow = 0;   /* Flow Updates provided in units of kg/s. */
        public static final int flowType_VolumeFlow = 1; /* This option of ContamX was incorporated for co-simulation between
                                                          * EnergyPlus and CONTAM. ContamX will convert the mass flows using the
                                                          * EnergyPlus psychrometric function PsyRhoAirFnPbTdbW() according to the
                                                          * rules for calculating interzone, infiltration, and ventilation system
                                                          * flows in EnergyPlus. */
        public static final int flowType_Last = 2;       /* Placeholder after last option for range checking. */
    }

    public static interface eDensityCalc
    {
        public static final int densityCalc_ContamX = 0;    /* Use humidity ratio provided via co-simulation to determine
                                                             * density used in airflow calculations. This method will
                                                             * use EnergyPlus density calculation method. */
        public static final int densityCalc_EnergyPlus = 1; /* Use humidity ratio provided via co-simulation to determine
                                                             * density used in airflow calculations. This method will
                                                             * use EnergyPlus density calculation method. */
        public static final int densityCalc_Last = 2;       /* Placeholder after last option for range checking. */
    }

    // COSIM_OPTIONS
    @Structure.FieldOrder({"flowType","densityCalc"})
    public static class COSIM_OPTIONS extends Structure {
        public eFlowType flowType;          /* Units of airflow when using the get flow APIs. */
        public eDensityCalc densityCalc;    /* Density calculation method to use during co-simulation. */
    }

    int cxiSetCosimOption(Pointer contamXState, int option, int value);

    public static interface eSimStage
    {
        public static final int simStage_Invalid = 0; /* Invalid ContamXState or ContamXState->commonState */
        public static final int simStage_Initial = 1; /* cxiGetContamState() has been called, callbacks can be registered, and simulation modes may be set. */
        public static final int simStage_Setup = 2;   /* cxiSetupSimulation() has been called, PRJ has been read, PRJ information may be obtained. */
        public static final int simStage_Calculation = 3; /* projectDataReady callback has returned and stepping through simulation can commence. */
        public static final int simStage_End = 4; /* Final time step has been performed, and cxiEndSimulation() should be called. */
    }

    // ZONE_COSIM_DSC
    @Structure.FieldOrder({"nr","flags","Vol","level_name","level_nr","name"})
    public static class ZONE_COSIM_DSC extends Structure {
        public int nr;          /* Zone number. */
        public int flags;       /* Airflow node flags. */
        public float Vol;       /* Zone volume, units [m3]. */
        public byte[] level_name = new byte[cxLibConsts.NAMEFIELDLEN];    /* Level name. */
        public int level_nr;                                              /* Level number. */
        public byte[] name = new byte[cxLibConsts.NAMEFIELDLEN];          /* Zone name. */
    }

    // PATH_COSIM_DSC
    @Structure.FieldOrder({"nr","flags","from_zone","to_zone","ahs_nr","X","Y","Z","envIndex"})
    public static class PATH_COSIM_DSC extends Structure {
        public int nr;          /* Airflow path sequence number assigned by ContamX. */
        public int flags;       /* Airflow path flag values */
        public int from_zone;   /* Zone number, positive airflow when flow is from this zone. */
        public int to_zone;     /* Zone number, positive airflow when flow is to this zone. */
        public int ahs_nr;      /* The number of the Simple Air-handling System that the path serves - return/supply only. */
        public float X;         /* X coordinate of the airflow path, units [m]. This value is entered directly in ContamW. */
        public float Y;         /* Y coordinate of the airflow path, units [m]. This value is entered directly in ContamW. */
        public float Z;         /* Z coordinate of the airflow path, units [m]. */
        public int envIndex;    /* Index identifies order of specifying values in WPC file */
    }

    // JCT_COSIM_DSC
    @Structure.FieldOrder({"nr","flags","containing_zone","envIndex"})
    public static class JCT_COSIM_DSC extends Structure {
        public int nr;          /* Junction number. */
        public int flags;       /* Airflow node flags */
        public int containing_zone;   /* Zone number in which junction is located. */
        public int envIndex;    /* Index identifies order of specifying values in WPC file. */
    }

    // TERM_COSIM_DSC
    @Structure.FieldOrder({"nr","flags","X","Y","Z","relHt","to_zone","envIndex"})
    public static class TERM_COSIM_DSC extends Structure {
        public int nr;          /* Junction number. */
        public int flags;       /* Airflow path flag values */
        public float X;         /* X coordinate of the airflow terminal, units [m]. This value is entered directly in ContamW. */
        public float Y;         /* Y coordinate of the airflow terminal, units [m]. This value is entered directly in ContamW. */
        public float Z;         /* Z coordinate of the airflow terminal, units [m]. */
        public float relHt;     /* terminal height relative to level [m] */
        public int to_zone;     /* Zone number, in which terminal is located. */
        public int envIndex;    /* Index identifies order of specifying values in WPC file */
    }

    // AHS_COSIM_DSC
    @Structure.FieldOrder({"nr","name","zone_ret","zone_sup","path_rec","path_oa","path_exh"})
    public static class AHS_COSIM_DSC extends Structure {
        public int nr;          /* Simple AHS number. */
        public byte[] name = new byte[cxLibConsts.NAMEFIELDLEN];    /* Simple AHS name. */
        public int zone_ret;    /* Return zone number. */
        public int zone_sup;    /* Supply zone number. */
        public int path_rec;    /* Recirculation path number. */
        public int path_oa;     /* Outdoor air path number. */
        public int path_exh;    /* Exhaust path number. */
    }

    // CONTROL_COSIM_DSC
    @Structure.FieldOrder({"nr","name"})
    public static class CONTROL_COSIM_DSC extends Structure {
        public int nr;                                              /* Control number. */
        public byte[] name = new byte[cxLibConsts.NAMEFIELDLEN];    /* Control name. */
    }

    // PrjDataReady callback function.
    public interface CallBackFnName extends Callback {
        void callback(Pointer contamXState, Pointer pUD);
    }
    public void cxiRegisterCallback_PrjDataReady(Pointer contamXState, Pointer pUD, cxLibInterface.CallBackFnName fnName);

    // ErrorReport callback function (not tested)
///    public interface CallBackErrorFnName extends Callback {
///        void callback(Pointer contamXState, byte[] headerStr, byte[] messageStr, int nonFatalErrorCt);
///    }
    public interface CallBackErrorFnName extends Callback {
        void callback(Pointer contamXState, Pointer headerStr, Pointer messageStr, IntByReference pNonFatalErrorCount);
    }
    public void cxiRegisterCallback_Error(Pointer contamXState, cxLibInterface.CallBackErrorFnName fnName);

    // DO
    void cxiDoCoSimStep(Pointer contamXState, int stepForward);

    // GETs
    void cxiEndSimulation(Pointer contamXState);
    int cxiGetAhsInfo(Pointer contamXState, int ahsNumber, AHS_COSIM_DSC pAhsDsc);
    int cxiGetAhsNumber(Pointer contamXState, byte[] ahsName, IntByReference pAhsNumber);
    Pointer cxiGetContamState();
    int cxiIsStateValid(Pointer contamXState);
    int cxiGetSimStage(Pointer contamXState);
    int cxiGetCtmName(Pointer contamXState, int ctmNumber, byte[] strName);
    int cxiGetCurrentDate(Pointer contamXState);
    int cxiGetCurrentTime(Pointer contamXState);
    int cxiGetEnvelopeExfil(Pointer contamXState, int envIndex, int ctmNumber, DoubleByReference pMass );
    int cxiGetInputControlInfo(Pointer contamXState, int inputControlIndex, CONTROL_COSIM_DSC pControl);
    int cxiGetJunctionInfo(Pointer contamXState, int jctNumber, JCT_COSIM_DSC pJct);
    int cxiGetLeakFlow(	Pointer contamXState, int leakNumber, DoubleByReference pFlow);
    int cxiGetLeakInfo(	Pointer contamXState, int leakNumber, TERM_COSIM_DSC pLeak);
    int cxiGetLeakNumber(Pointer contamXState, int jctNumber, IntByReference pLeakNumber);
    int cxiGetNumAHS(Pointer contamXState);
    int cxiGetNumCtms(Pointer contamXState);
    int cxiGetNumInputCtrlNodes(Pointer contamXState);
    int cxiGetNumJunctions(Pointer contamXState);
    int cxiGetNumLeaks(Pointer contamXState);
    int cxiGetNumOutputCtrlNodes(Pointer contamXState);
    int cxiGetNumPaths(Pointer contamXState);
    int cxiGetNumTerminals(Pointer contamXState);
    int cxiGetNumZones(Pointer contamXState);
    int cxiGetOutputControlInfo(Pointer contamXState, int outputControlIndex, CONTROL_COSIM_DSC pControl);
    int cxiGetOutputControlValue(Pointer contamXState, int outputCtrlNumber, FloatByReference pCtrlValue);
    int cxiGetPathFlows(Pointer contamXState, int pathNumber, DoubleByReference pFlow0, DoubleByReference pFlow1);
    int cxiGetPathInfo(Pointer contamXState, int pathNumber, PATH_COSIM_DSC pPathDsc);
    int cxiGetSimulationEndDate(Pointer contamXState);
    int cxiGetSimulationEndTime(Pointer contamXState);
    int cxiGetSimulationStartDate(Pointer contamXState);
    int cxiGetSimulationStartTime(Pointer contamXState);
    int cxiGetSimulationTimeStep(Pointer contamXState);
    int cxiGetTermFlow(Pointer contamXState, int termNumber, DoubleByReference pFlow);
    int cxiGetTermInfo(Pointer contamXState, int termNumber, TERM_COSIM_DSC	pTerm);
    int cxiGetVersion(Pointer contamXState, byte[] strVersion);
    int cxiGetZoneInfo(Pointer contamXState, int zoneNumber, ZONE_COSIM_DSC pZoneInfo);
    int cxiGetZoneMF(Pointer contamXState, int zoneNumber, int ctmNumber, DoubleByReference pMassFraction);
    int cxiGetZoneNumber(Pointer contamXState, byte[] zoneName, int zoneLevelNumber, IntByReference pZoneNumber);
    int cxiGetZoneVolume(Pointer contamXState, int zoneNumber, FloatByReference pVolume);

    // SETs
    int cxiSetAHSPercentOA(Pointer contamXState, int ahsNumber, float OAValue);
    int cxiSetAmbtHumRatio(Pointer contamXState, float humRatio);
    int cxiSetAmbtMassFraction(Pointer contamXState, int ctmNumber, double Mf);
    int cxiSetAmbtPressure(Pointer contamXState, float ambtPres);
    int cxiSetAmbtTemperature(Pointer contamXState, float ambtTemp);
    int cxiSetAmbtWndDir(Pointer contamXState, float wndDir);
    int cxiSetAmbtWndSpd(Pointer contamXState, float wndSpd);
    int cxiSetEnvelopeMF(Pointer contamXState, int envIndex, int ctmNumber, double Mf);
    int cxiSetEnvelopeWP(Pointer contamXState, int envIndex, float wP);
    int cxiSetInputControlValue(Pointer contamXState, int inputCtrlNumber, float ctrlValue);
    int cxiSetJunctionTemperature (Pointer contamXState, int jctNumber, double temperature);
    int cxiSetSupplyReturnPathFlow(Pointer contamXState, int pathNumber, float flow);
    int cxiSetupSimulation(Pointer contamXState, String prjPath, int useCosim);
    void cxiSetWindPressureMode(Pointer contamXState, int useWP);
    int cxiSetZoneAddMass(Pointer contamXState, int zoneNumber, int ctmNumber, double addMass);
    int cxiSetZoneHumRatio(Pointer contamXState, int zoneNumber, double humRatio);
    int cxiSetZoneTemperature(Pointer contamXState, int zoneNumber, double temperature);
}
