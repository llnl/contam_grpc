package cxLibs;

public final class cxLibConsts {
    public final static int NAMEMAXLEN = 40;   // Maximum length of a name allowed to be entered via ContamW
    public final static int NAMEFIELDLEN = 48; // Size of a name field to allow for AHS zone/path naming to include (SUP) or (REC)
}
